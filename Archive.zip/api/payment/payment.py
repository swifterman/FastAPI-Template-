from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from api.payment import models
from api.token.main import get_current_user
from api.user_management.schemas import User
from api.enums.enums import PaymentStatus
from api.payment.schemas import Payment, PaymentCreate
from database.database import get_db

router = APIRouter(prefix='/payment', tags=['Payment'], responses={400: {'description': 'Bad Request'}})


@router.post('/create', response_model=Payment)
def create_a_payment(new_payment: PaymentCreate,
                     current_user: Annotated[User, Depends(get_current_user)],
                     db: Session = Depends(get_db)):
    try:
        db_new_payment = models.Payment(amount=new_payment.amount,
                                        status=PaymentStatus.PENDING,
                                        currency=new_payment.currency,
                                        user_id=current_user.id)
        db.add(db_new_payment)
        db.commit()
        db.refresh(db_new_payment)
        return db_new_payment
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


